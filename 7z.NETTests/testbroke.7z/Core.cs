﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SevenZipNET
{
    internal static class Core
    {
        public static string ExePath
        {
            get
            {
                if (Environment.Is64BitOperatingSystem)
                {
                    return Environment.CurrentDirectory + @"\7za64.exe";
                }
                else
                {
                    return Environment.CurrentDirectory + @"\7za.exe";
                }
            }
        }
    }
}
