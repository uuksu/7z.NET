﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using SevenZipNET.Arguments;

namespace SevenZipNET
{
    /// <summary>
    /// Provides reading and extraction functionality from an already existing archive.
    /// </summary>
    public class SevenZipExtractor
    {
        private string archive;

        internal static Regex indexReg = new Regex(@"^(\d{2,4}-\d{2,4}-\d{2,4})\s+(\d{2}:\d{2}:\d{2})\s+(.{5})\s+(\d+)\s+(\d+)?\s+(.+)");

        /// <param name="filename">Path to the archive.</param>
        public SevenZipExtractor(string filename)
        {
            if (filename == null)
                throw new ArgumentNullException(nameof(filename));

            if (!File.Exists(filename))
                throw new ArgumentException("File could not be found.", nameof(filename));

            archive = filename;

            _indexCache = new Lazy<IReadOnlyList<ArchiveFile>>(Index);
        }

        /// <summary>
        /// Returns a list of files inside the archive.
        /// </summary>
        /// <returns>The list of files inside the archive.</returns>
        protected IReadOnlyList<ArchiveFile> Index()
        {
            List<ArchiveFile> files = new List<ArchiveFile>();

            WProcess p = new WProcess(new ArgumentBuilder()
                .AddCommand(SevenZipCommands.List, archive)
                .ToString()
                );
            //WProcess p = new WProcess("l \"" + archive + "\"");

            foreach (string line in p.Execute())
            {
                if (indexReg.IsMatch(line))
                {
                    ArchiveFile file = ArchiveFile.Parse(line);
                    files.Add(file);
                }
            }
            
            return files.AsReadOnly();
        }

        private Lazy<IReadOnlyList<ArchiveFile>> _indexCache;

        /// <summary>
        /// Information relating to each file stored inside the archive.
        /// </summary>
        public IReadOnlyList<ArchiveFile> Files
        {
            get
            {
                return _indexCache.Value;
            }
        }


    }
}
