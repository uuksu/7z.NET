﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace SevenZipNET
{
    /// <summary>
    /// A wrapper for the <c>Process</c> class.
    /// </summary>
    /// <seealso cref="Process"/>
    internal class WProcess
    {
        private Process _process;
        private PerformanceCounter _perf;
        private ulong _expected = 0;
        private ulong _actual = 0;

        public WProcess()
        {
            _process = new Process();
            _process.StartInfo.FileName = Core.ExePath;
            
            _process.StartInfo.CreateNoWindow = true;
            _process.StartInfo.UseShellExecute = false;
            _process.StartInfo.RedirectStandardOutput = true;
        }

        /// <param name="arguments">The string of arguments to start the process with.</param>
        public WProcess(string arguments) : this()
        {
            _process.StartInfo.Arguments = arguments;
        }
        
        /// <param name="expectedBytes">The expected amount of bytes to be written to disk by this process.</param>
        public WProcess(ulong expectedBytes) : this()
        {
            _expected = expectedBytes;

            _perf = new PerformanceCounter("Process", "IO Write Bytes / sec");
        }

        public WProcess(string arguments, ulong expectedBytes) : this(expectedBytes)
        {
            _process.StartInfo.Arguments = arguments;
        }

        /// <summary>
        /// Starts a process and returns the outputted console text.
        /// </summary>
        /// <returns>Output console data.</returns>
        public string[] Execute()
        {
            List<string> output = new List<string>();
            _process.OutputDataReceived += ((s, e) => {
                output.Add(e.Data);
            });
            
            _process.Start();
            _process.BeginOutputReadLine();

            if (_expected > 0)
            {
                Timer t = new Timer(1000);

                t.Elapsed += (s, e) => {

                };
            }

            _process.WaitForExit();

            return output.ToArray();
        }
    }
}
